"""Dataset provenance, training-only preprocessing and dense accuracy references."""
from __future__ import annotations

from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
from time import perf_counter
from urllib.request import urlopen
from zipfile import ZipFile

import numpy as np
from scipy.linalg import cho_factor, cho_solve
from scipy.spatial.distance import cdist, pdist


SOURCES = {
    "concrete": {
        "url": "https://archive.ics.uci.edu/static/public/165/concrete%2Bcompressive%2Bstrength.zip",
        "page": "https://archive.ics.uci.edu/dataset/165/concrete+compressive+strength",
        "doi": "10.24432/C5PK67", "rows": 1030, "features": 8,
        "citation": "Yeh, I. (1998). Concrete Compressive Strength. UCI Machine Learning Repository.",
    },
    "airfoil": {
        "url": "https://archive.ics.uci.edu/static/public/291/airfoil%2Bself%2Bnoise.zip",
        "page": "https://archive.ics.uci.edu/dataset/291/airfoil+self+noise",
        "doi": "10.24432/C5VW2C", "rows": 1503, "features": 5,
        "citation": "Brooks, T., Pope, D., and Marcolini, M. (1989). Airfoil Self-Noise. UCI Machine Learning Repository.",
    },
}


def acquire(root):
    root = Path(root)
    raw = root/"data/raw"
    raw.mkdir(parents=True, exist_ok=True)
    manifest = {}
    for name, source in SOURCES.items():
        archive = raw/f"{name}.zip"
        if not archive.exists():
            with urlopen(source["url"], timeout=45) as response:
                content = response.read()
            archive.write_bytes(content)
        content = archive.read_bytes()
        with ZipFile(BytesIO(content)) as z:
            if name == "concrete":
                import xlrd
                member = next(p for p in z.namelist() if p.lower().endswith("concrete_data.xls"))
                sheet = xlrd.open_workbook(file_contents=z.read(member)).sheet_by_index(0)
                values = np.asarray([sheet.row_values(i) for i in range(1, sheet.nrows)], dtype=float)
            else:
                member = next(p for p in z.namelist() if p.endswith("airfoil_self_noise.dat"))
                values = np.loadtxt(BytesIO(z.read(member)))
        assert values.shape == (source["rows"], source["features"]+1)
        assert np.all(np.isfinite(values))
        dest = root/"data"/f"{name}.npz"
        np.savez_compressed(dest, X=values[:, :-1], y=values[:, -1])
        manifest[name] = dict(source, archive_sha256=sha256(content).hexdigest(),
                              extracted_member=member,
                              arrays_sha256=sha256(values.tobytes()).hexdigest(),
                              license="CC BY 4.0", obtained="2026-11-23")
    (root/"data/manifest.json").write_text(json.dumps(manifest, indent=2)+"\n", encoding="utf-8")
    return manifest


def raw_data(root, dataset, seed, target="observed", synthetic_n=640):
    if dataset != "synthetic":
        with np.load(Path(root)/"data"/f"{dataset}.npz") as data:
            return data["X"], data["y"]
    rng = np.random.default_rng(np.random.SeedSequence([seed, 6220, 10]))
    centers = rng.normal(0, 1.5, (4, 8))
    labels = rng.choice(4, synthetic_n, p=[.5, .25, .15, .10])
    X = centers[labels]+rng.normal(0, .45, (synthetic_n, 8))
    target_rng = np.random.default_rng(np.random.SeedSequence([seed, 6220, 11]))
    if target == "smooth":
        y = np.sin(X[:, 0])+.3*X[:, 1]**2-.2*X[:, 2]+.05*target_rng.normal(size=synthetic_n)
    elif target == "random":
        y = target_rng.normal(size=synthetic_n)
    else:
        raise ValueError(f"Unknown synthetic target {target}")
    return X, y


def prepare(root, dataset, seed, regularization, target="observed", synthetic_n=640):
    """Prepare a case; reference Cholesky and dense K never enter the solve worker."""
    started = perf_counter()
    root = Path(root)
    X, y = raw_data(root, dataset, seed, target, synthetic_n)
    split_rng = np.random.default_rng(np.random.SeedSequence([seed, 6220, 12]))
    order = split_rng.permutation(len(y))
    cut = int(.8*len(y))
    train, test = order[:cut], order[cut:]
    Xtr, Xte = X[train], X[test]
    mean, std = Xtr.mean(axis=0), Xtr.std(axis=0)
    std[std == 0] = 1
    Xtr, Xte = (Xtr-mean)/std, (Xte-mean)/std
    ymean, ystd = float(y[train].mean()), float(y[train].std())
    ystd = ystd if ystd else 1.0
    ytr, yte = (y[train]-ymean)/ystd, (y[test]-ymean)/ystd
    bandwidth = float(np.median(pdist(Xtr)))
    if bandwidth <= 0:
        raise ValueError("Median training distance is zero")
    preprocessing_seconds = perf_counter()-started
    reference_started = perf_counter()
    K = np.exp(-cdist(Xtr, Xtr, "sqeuclidean")/(2*bandwidth**2))
    K.flat[::len(ytr)+1] += regularization
    alpha = cho_solve(cho_factor(K, lower=True, check_finite=False), ytr, check_finite=False)
    reference_residual = float(np.linalg.norm(ytr-K @ alpha)/np.linalg.norm(ytr))
    predictions = np.exp(-cdist(Xte, Xtr, "sqeuclidean")/(2*bandwidth**2)) @ alpha
    reference_seconds = perf_counter()-reference_started
    config = dict(dataset=dataset, seed=seed, target=target, regularization=regularization,
                  synthetic_n=synthetic_n if dataset == "synthetic" else None,
                  n_train=len(ytr), n_test=len(yte), bandwidth=bandwidth,
                  train_fraction=.8, preprocessing_seconds=preprocessing_seconds,
                  reference_seconds=reference_seconds, reference_relative_residual=reference_residual,
                  dataset_sha256=sha256(np.ascontiguousarray(np.column_stack((X, y))).tobytes()).hexdigest(),
                  train_indices_sha256=sha256(train.tobytes()).hexdigest())
    size = f"-n{synthetic_n}" if dataset == "synthetic" else ""
    case_id = f"{dataset}{size}-{target}-s{seed}-lambda{regularization:g}"
    prepared = root/"data/prepared"
    prepared.mkdir(parents=True, exist_ok=True)
    path = prepared/f"{case_id}.npz"
    np.savez_compressed(path, X_train=Xtr, X_test=Xte, y_train=ytr, y_test=yte,
                        alpha_reference=alpha, prediction_reference=predictions,
                        bandwidth=bandwidth, y_std=ystd, config=json.dumps(config))
    return path, config


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path.cwd())
    args = parser.parse_args()
    print(json.dumps(acquire(args.root), indent=2))
